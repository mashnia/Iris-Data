# Write a Python program to load the iris data from a given csv file into a dataframe and print the shape of the data, type of the data and first 3 rows.

import pandas as pd

data = pd.read_csv("iris.csv")

print("Shape of the data:")
print(data.shape)

print("\nData Type:")
print(type(data))

print("\nFirst 3 rows:")
print(data.head(3))