# Write a Python program using Scikit-learn to print the keys, number of rows-columns, feature names and the description of the Iris data.

import pandas as pd

data = pd.read_csv("iris.csv")

print("\nKeys of Iris dataset:")
print(data.keys())
print("\nNumber of rows and columns of Iris dataset:")
print(data.shape) 