# Write a Python program to drop Id column from a given Dataframe and print the modified part.

# Call iris.csv to create the Dataframe.

# This file does not include Id column. Instead, we'll just print the Dataframe.

import pandas as pd

data = pd.read_csv("iris.csv")

print(data) 