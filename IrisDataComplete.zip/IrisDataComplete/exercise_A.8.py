# Write a Python program to access first four cells from a given Dataframe using the index and column labels. Call iris.csv to create the Dataframe.

import pandas as pd

data = pd.read_csv("iris.csv")

x = data.iloc[0][0], data.iloc[0][1], data.iloc[0][2], data.iloc[0][3]

print("Data from first four cells:")
print(x)

print("\nCould also be printed this way:")
print(data.head(1))