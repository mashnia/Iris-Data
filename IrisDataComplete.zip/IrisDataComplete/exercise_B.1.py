# Write a Python program to create a plot to get a general Statistics of Iris data.

import pandas as pd
import matplotlib.pyplot as plt

iris = pd.read_csv("iris.csv")
iris.describe().plot(kind = "area",fontsize=16, figsize = (15,8), colormap="Accent")
plt.xlabel('Statistics', fontsize=14)
plt.ylabel('Value', fontsize=14)
plt.legend(loc=(0.85,.45))
plt.title("General Statistics of Iris Dataset", fontsize=16)


plt.show()

table=iris.describe()
print("Data Table for Plot:")
print(table)