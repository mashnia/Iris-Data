# Write a Python program to create a joinplot and add regression and kernel density fits using "reg" to describe individual distributions on the same plot between Sepal length and Sepal width.


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

iris = pd.read_csv("iris.csv")

fig=sns.jointplot(x='sepal_length', y='sepal_width', kind="reg", color='blue', data=iris) 
plt.show()