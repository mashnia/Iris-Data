# Write a Python program to draw a scatterplot, then add a joint density estimate to 
# describe individual distributions on the same plot between Sepal length and Sepal width

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

iris = pd.read_csv("iris.csv")

sns.jointplot(x = iris.sepal_length, y = iris.sepal_width, data=iris, color="b").plot_joint(sns.kdeplot, zorder=0, n_levels=6) 
plt.show()