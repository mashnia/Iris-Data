# Write a Python program to create a pairplot of the iris data set and check which flower species seems to be the most separable.

import seaborn as sns
import pandas as pd

data = pd.read_csv("iris.csv")
sns.set()
sns.pairplot(data, hue='species', height=1.5)

