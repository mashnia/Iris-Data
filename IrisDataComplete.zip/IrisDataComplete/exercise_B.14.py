# Write a Python program using seaborn to Create a kde (Kernel Density Estimate ) plot of sepal_length versus sepal width for setosa species of flower.

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt 
iris = pd.read_csv("iris.csv")

sns.set(style="darkgrid")

sub=iris[iris['species']=='setosa']
sns.kdeplot(x=sub.sepal_length,y=sub.sepal_width, cmap="plasma", shade=True)
plt.title('Iris-setosa')
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Sepal Width (cm)')
plt.show()

