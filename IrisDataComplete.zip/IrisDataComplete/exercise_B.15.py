# Write a Python program using seaborn to Create a kde (Kernel Density Estimate ) plot of petal_length versus petal width for setosa species of flower.

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt 
iris = pd.read_csv("iris.csv")

sns.set(style="darkgrid")

sub=iris[iris['species']=='setosa']
sns.kdeplot(x=sub.petal_length,y=sub.petal_width, cmap="plasma", shade=True)
plt.title('Iris-setosa')
plt.xlabel('Petal Length Cm')
plt.ylabel('Petal Width Cm')
plt.show()