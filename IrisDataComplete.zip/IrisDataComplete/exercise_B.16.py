#  Write a Python program using seaborne to create a kde (Kernel Density Estimate) plot of two shaded bivariate densities of Sepal Width and Sepal Length

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt 

iris = pd.read_csv("iris.csv")

sns.set(style="darkgrid")

# Set up the figure
f, ax = plt.subplots(figsize=(8, 8))
ax.set_aspect("equal")

# Subset the iris dataset by species
setosa = iris[iris["species"] == 'setosa']
virginica = iris[iris["species"] == 'virginica']

# Draw the two density plots
ax = sns.kdeplot(x=setosa.petal_width, y=setosa.petal_length,
                 cmap="Reds", shade=True)
ax = sns.kdeplot(x=virginica.petal_width, y=virginica.petal_length,
                 cmap="Blues", shade=True)

# Add labels to the plot
red = sns.color_palette("Reds")[-2]
blue = sns.color_palette("Blues")[-2]
ax.text(3, 5.5, "virginica", size=14, color=blue)
ax.text(3, 1.3, "setosa", size=14, color=red)

plt.show()