# Write a Python program to find the correlation between variables of iris data. Also create a hitmap using Seaborn to present their relations.


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

iris = pd.read_csv("iris.csv")

X = iris.iloc[:, 0:4]
f, ax = plt.subplots(figsize=(10, 8))
corr = X.corr()
print(corr)
sns.heatmap(corr, mask=np.zeros_like(corr, dtype=np.bool), square=True, ax=ax, linewidths=.5)
plt.show() 