# Write a Python program to create a Bar plot to get the frequency of the three species of the Iris data.

import seaborn as sns
import matplotlib.pyplot as plt

iris = sns.load_dataset("iris")

ax = sns.countplot(x="species", data=iris)

plt.title("Iris Species Count")
plt.show()