# Write a Python program to create a graph to see how the length and width of SepalLength, SepalWidth, PetalLength, PetalWidth are distributed.


import pandas as pd
import matplotlib.pyplot as plt

iris = pd.read_csv("iris.csv")

iris.hist(edgecolor='black')

fig=plt.gcf()
fig.set_size_inches(13,13)

plt.show()