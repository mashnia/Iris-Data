# Write a Python program to create a joinplot using "kde" to describe individual
# distributions on the same plot between Sepal length and Sepal width. 
# Note: The kernel density estimation (kde) procedure visualize a bivariate distribution. # In seaborn, this kind of plot is shown with a contour plot and is available as a style 
# in jointplot().

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

iris = pd.read_csv("iris.csv")

# Basic 2D density plot
sns.kdeplot(x=iris.sepal_width, y=iris.sepal_length)
plt.title("2D density plot")
plt.show()

 
# Custom the color, add shade and bandwidth
sns.kdeplot(x=iris.sepal_width, y=iris.sepal_length, cmap="Oranges", shade=True, bw_adjust=.5)
plt.title("With shade and bandwidth")
plt.show()

# Add thresh parameter
sns.kdeplot(x=iris.sepal_width, y=iris.sepal_length, cmap="Blues", shade=True, thresh=0)
plt.title("With thresh parameter")
plt.show()