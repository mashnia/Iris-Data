# Write a Python program to view some basic statistical details like percentile, mean, std etc. of the species of 'Iris-setosa', 'Iris-versicolor' and 'Iris-versicolor'.


import pandas as pd

data = pd.read_csv("iris.csv")

print('Iris-setosa')
setosa = data['species'] == 'setosa'
print(data[setosa].describe())
print('\nIris-versicolor')
setosa = data['species'] == 'versicolor'
print(data[setosa].describe())
print('\nIris-virginica')
setosa = data['species'] == 'virginica'
print(data[setosa].describe())
