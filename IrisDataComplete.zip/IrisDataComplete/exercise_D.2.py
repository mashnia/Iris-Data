# Write a Python program to create a scatter plot using sepal length and petal_width to separate the Species classes.


import pandas as pd
import matplotlib.pyplot as plt
from sklearn import preprocessing


iris = pd.read_csv("iris.csv")

#Convert Name columns in a numerical column of the iris dataframe
#creating labelEncoder
le = preprocessing.LabelEncoder()
# Converting string labels into numbers.
iris.species = le.fit_transform(iris.species)
x = iris.iloc[:, :-1].values
y = iris.iloc[:, 4].values
plt.scatter(x[:,0], x[:, 3], c=y)
plt.xlabel('Sepal Length ')
plt.ylabel('Petal Width ')
plt.show()